package atendimento;

public enum Situation {
	

}
